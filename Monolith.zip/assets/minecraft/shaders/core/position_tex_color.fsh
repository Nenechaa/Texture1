#version 330
#extension GL_ARB_separate_shader_objects : require

layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    mat4 TextureMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
};

uniform sampler2D Sampler0;

layout(location = 0) in vec2 texCoord0;
layout(location = 1) in vec4 vertexColor;
layout(location = 2) in vec2 muiPos;
layout(location = 3) flat in vec2 muiSize;
layout(location = 4) flat in float muiSeated;

layout(location = 0) out vec4 fragColor;

bool mui_in(vec2 p, vec2 a, vec2 b) { return p.x >= a.x && p.x <= b.x && p.y >= a.y && p.y <= b.y; }
bool mui_hud(vec2 pos, vec2 size) {
    float cx = floor(size.x / 2.0);
    return mui_in(pos, vec2(cx - 122.0, size.y - 24.0), vec2(cx + 122.0, size.y))
        || mui_in(pos, vec2(cx - 92.0, size.y - 64.0), vec2(cx + 92.0, size.y - 22.0));
}
bool mui_crosshair(vec2 pos, vec2 size) {
    vec2 c = floor(size / 2.0);
    return mui_in(pos, c - 9.0, c + 9.0);
}

void main() {
    if (muiSeated > 0.5 && textureSize(Sampler0, 0) != ivec2(16, 16)) {
        if (mui_hud(muiPos, muiSize)) discard;
    }
    vec4 color = texture(Sampler0, texCoord0) * vertexColor;
    if (muiSeated > 0.5 && mui_crosshair(muiPos, muiSize) && all(greaterThan(color.rgb, vec3(0.99)))) discard;
    if (color.a == 0.0) discard;
    fragColor = color * ColorModulator;
}
