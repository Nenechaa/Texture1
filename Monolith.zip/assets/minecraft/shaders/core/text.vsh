#version 330
#extension GL_ARB_separate_shader_objects : require

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#include <minecraft:sample_lightmap.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>
#include <minecraft:globals.glsl>

uniform sampler2D Sampler0;

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 3) in ivec2 UV2;
uniform sampler2D Sampler2;
layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
#endif

layout(location = 2) out vec4 vertexColor;
layout(location = 3) out vec2 texCoord0;

void mui_vanilla_vertex() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
#else
    vertexColor = Color;
#endif
    texCoord0 = UV0;
}

bool mui_near(float v, float t) { return abs(v - t) < 0.0001; }
bool mui_grid(float v) { return mui_near(v, 0.0) || mui_near(v, 0.5) || mui_near(v, 1.0); }
float mui_flag(float v) { return (abs(fract(v * 16.0) - 0.375000) < 0.002 || abs(fract(-v * 16.0) - 0.375000) < 0.002) ? 1.0 : 0.0; }
int mui_flag_axis() {
    vec3 f = -CameraOffset;
    if (mui_flag(f.x) > 0.0 && mui_flag(f.y) > 0.0 && mui_flag(f.z) > 0.0) return 1;
    if (mui_flag(f.x) > 0.0) return 0;
    if (mui_flag(f.z) > 0.0) return 2;
    return -1;
}
float mui_seated_flag() { return mui_flag_axis() >= 0 ? 1.0 : 0.0; }
float mui_seated_now() { return ProjMat[3][3] != 1.0 ? 0.0 : mui_seated_flag(); }
vec2 mui_gui_size() { return vec2(2.0 / abs(ProjMat[0][0]), 2.0 / abs(ProjMat[1][1])); }
float mui_reversed() { return ProjMat[2][2] > -0.5 ? 1.0 : 0.0; }
bool mui_in(vec2 p, vec2 a, vec2 b) { return p.x >= a.x && p.x <= b.x && p.y >= a.y && p.y <= b.y; }
bool mui_hud(vec2 pos, vec2 size) {
    float cx = floor(size.x / 2.0);
    return mui_in(pos, vec2(cx - 122.0, size.y - 24.0), vec2(cx + 122.0, size.y))
        || mui_in(pos, vec2(cx - 92.0, size.y - 64.0), vec2(cx + 92.0, size.y - 22.0));
}
bool mui_crosshair(vec2 pos, vec2 size) {
    vec2 c = floor(size / 2.0);
    return mui_in(pos, c - 9.0, c + 9.0);
}
uint mui_mul(uint a, uint b) {
    uint al = a & 65535u, ah = a >> 16u, bl = b & 65535u, bh = b >> 16u;
    return al * bl + ((al * bh + ah * bl) << 16u);
}
uint mui_displacements(uint i) {
    uvec4 t0_0 = (i & 8u) != 0u ? uvec4(391774590u, 1662151960u, 339798529u, 53280883u) : uvec4(906494208u, 342563082u, 67249448u, 161304064u);
    uvec4 t0_1 = (i & 8u) != 0u ? uvec4(2843839628u, 2316404752u, 679716608u, 3477053313u) : uvec4(25034762u, 2349278011u, 118704130u, 203165200u);
    uvec4 t1_0 = (i & 4u) != 0u ? t0_1 : t0_0;
    uvec2 h = (i & 2u) != 0u ? t1_0.zw : t1_0.xy;
    return (i & 1u) != 0u ? h.y : h.x;
}
int mui_symbol_of(vec3 rgb) {
    uvec3 c = uvec3(round(rgb * 255.0));
    uint k = (c.r << 16u) | (c.g << 8u) | c.b;
    uint b = mui_mul(k, 1372926309u) >> 26u;
    uint s = ((mui_mul(k, 3137834733u) >> 24u) * 240u >> 8u) + ((mui_displacements(b >> 2u) >> ((b & 3u) << 3u)) & 255u);
    return int(s >= 240u ? s - 240u : s);
}
ivec2 muiBase = ivec2(0);
ivec3 mui_fetch(ivec2 p) { return ivec3(round(texelFetch(Sampler0, muiBase + p, 0).rgb * 255.0)); }
int mui_symbol(ivec2 p) { return mui_symbol_of(texelFetch(Sampler0, muiBase + p, 0).rgb); }
ivec4 mui_symbols(ivec2 p, vec3 first) {
    return ivec4(mui_symbol_of(first), mui_symbol(p + ivec2(1, 0)), mui_symbol(p + ivec2(0, 1)), mui_symbol(p + ivec2(1, 1)));
}
int mui_texture() {
    ivec2 size = textureSize(Sampler0, 0);
    if (size == ivec2(128, 128)) return 1;
    return size.x == size.y && size.x >= 256 && (size.x & 127) == 0 ? 2 : 0;
}
bool mui_in_texture(ivec2 base, ivec2 size) { return all(greaterThanEqual(base, ivec2(0))) && all(lessThan(base, size)); }
int mui_screen_map() {
    ivec3 m0 = mui_fetch(ivec2(0, 0)), m1 = mui_fetch(ivec2(1, 0));
    if (m0 != ivec3(89, 117, 105) || m1 != ivec3(109, 144, 129)) return 0;
    ivec3 a = mui_fetch(ivec2(0, 1)), b = mui_fetch(ivec2(1, 1));
    if (a == ivec3(67, 88, 79) && b == ivec3(67, 88, 79)) return 3;
    if (a == ivec3(127, 167, 150) && b == ivec3(67, 88, 79)) return 1;
    return 0;
}
vec4 mui_block(ivec2 b) {
    ivec2 p = b * 2;
    vec4 c00 = texelFetch(Sampler0, muiBase + p, 0);
    if (c00.a < 0.5) return vec4(0.0);
    ivec4 s = mui_symbols(p, c00.rgb);
    ivec4 digit = s & 7;
    return vec4(dot(vec4(s >> 3), vec4(0.25)) / 29.0, float(digit.x * 8 + digit.y - 32) / 63.0,
                float(digit.z * 8 + digit.w - 32) / 63.0, 1.0);
}
float mui_fill_right(int info) {
    vec4 a = mui_block(ivec2(info + 1, 0)), b = mui_block(ivec2(info + 1, 1));
    if (a.w != b.w) return 1.0;
    vec4 d = abs(a - b);
    return d.x + 0.5 * (d.y + d.z) > 0.06 ? 1.0 : 0.0;
}

vec4 mui_flat(vec2 ndc) {
    vec4 c = ProjMat * vec4(0.0, 0.0, -1.0, 1.0);
    return vec4(ndc * c.w, c.z, c.w);
}

vec2 mui_hot(vec2 size, vec3 ahead, float speed) {
    vec3 right = vec3(-ahead.z, 0.0, ahead.x);
    vec3 look = normalize(-vec3(ModelViewMat[0][2], ModelViewMat[1][2], ModelViewMat[2][2]));
    vec2 turn = degrees(vec2(atan(dot(look, right), dot(look, ahead)), asin(clamp(-look.y, -1.0, 1.0))));
    return clamp(size * 0.5 + turn * speed, vec2(12.0), size - vec2(40.0));
}

vec2 mui_client_pointer(vec2 size) {
    int flagAxis = mui_flag_axis();
    bool alongX = flagAxis == 0 || (flagAxis == 1 && abs(Position.x) > abs(Position.z));
    vec3 axis = alongX ? vec3(1.0, 0.0, 0.0) : vec3(0.0, 0.0, 1.0);
    float along = dot(Position, axis);
    vec3 ahead = axis * sign(along);
    vec3 right = vec3(-ahead.z, 0.0, ahead.x);
    vec2 hot = mui_hot(size, ahead, (abs(along) - 0.5) * 512.0);
    float aspectFix = (16.0 / 9.0) * (ScreenSize.y / max(ScreenSize.x, 1.0));
    vec2 px = hot + vec2(dot(Position, right) * aspectFix, -Position.y) * 128.0;
    return vec2(px.x / size.x * 2.0 - 1.0, 1.0 - px.y / size.y * 2.0);
}

vec2 mui_free_pointer(vec2 size, float yawByte, float pitchByte) {
    float yRad = radians(yawByte / 255.0 * 360.0 - 180.0);
    float pRad = radians(pitchByte / 255.0 * 150.0 - 75.0);
    vec2 hAhead = vec2(-sin(yRad), cos(yRad));
    vec2 hRight = vec2(-cos(yRad), -sin(yRad));
    vec3 ahead = vec3(hAhead.x * cos(pRad), -sin(pRad), hAhead.y * cos(pRad));
    vec3 right = vec3(hRight.x, 0.0, hRight.y);
    vec3 up = cross(right, ahead);
    vec3 look = normalize(-vec3(ModelViewMat[0][2], ModelViewMat[1][2], ModelViewMat[2][2]));
    vec2 turn = degrees(vec2(atan(dot(look, right), dot(look, ahead)), asin(clamp(-dot(look, up), -1.0, 1.0))));
    float speed = max(4.0, (Position.x - 0.5) * 512.0);
    vec2 hot = clamp(size * 0.5 + turn * speed, vec2(12.0), size - vec2(40.0));
    float aspectFix = (16.0 / 9.0) * (ScreenSize.y / max(ScreenSize.x, 1.0));
    vec2 px = hot + vec2(Position.z * aspectFix, -Position.y) * 128.0;
    return vec2(px.x / size.x * 2.0 - 1.0, 1.0 - px.y / size.y * 2.0);
}

vec2 muiUv;
int mui_locate() {
    muiUv = UV0;
    int tk = mui_texture();
    if (tk != 2) return tk == 1 ? mui_screen_map() : 0;
    ivec2 size = textureSize(Sampler0, 0);
    vec2 at = UV0 * vec2(size) / 128.0, k = round(at);
    if (any(greaterThan(abs(at - k), vec2(0.001)))) return 0;
    vec3 rel = Position - CameraOffset;
    if (mui_flag_axis() >= 0 && all(greaterThan(rel, vec3(-0.01))) && all(lessThan(rel, vec3(1.01)))) {
        vec2 corner = vec2(rel.x > 0.5 ? 1.0 : 0.0, (rel.y < 0.5) == (rel.z > 0.5) ? 1.0 : 0.0);
        muiBase = ivec2(k - corner) * 128;
        if (mui_in_texture(muiBase, size)) {
            int kind = mui_screen_map();
            if (kind >= 3) {
                muiUv = corner;
                return kind;
            }
        }
    }
    muiBase = ivec2(0);
    return 0;
}

ivec4 mui_tint_symbols() {
    return ivec4(mui_symbol(ivec2(4, 0)), mui_symbol(ivec2(5, 0)), mui_symbol(ivec2(4, 1)), mui_symbol(ivec2(5, 1)));
}

void mui_gui_vertex() {
    if (mui_seated_now() > 0.5) {
        vec2 pos = (ModelViewMat * vec4(Position, 1.0)).xy;
        vec2 size = mui_gui_size();
        float cx = floor(size.x / 2.0);
        if (mui_in(pos, vec2(cx - 40.0, size.y - 40.0), vec2(cx + 40.0, size.y - 22.0))) vertexColor.a = 0.0;
    }
}

void mui_world_vertex() {
    float seated = mui_seated_flag();
    bool rev = mui_reversed() > 0.5;
    int mapKind = 0;
#ifndef IS_GRAYSCALE
    mapKind = mui_locate();
#endif
    ivec3 vfxRgb = ivec3(round(Color.rgb * 255.0));
    if (vfxRgb.r == 251 && vfxRgb.g > 0 && mapKind == 0) {
        int corner = gl_VertexIndex & 3;
        texCoord0 = vec2((corner == 2 || corner == 3) ? 1.0 : 0.0, (corner == 1 || corner == 2) ? 1.0 : 0.0);
        vertexColor = vec4(float(vfxRgb.g), float(vfxRgb.b) / 255.0, 0.0, 1024.0);
        return;
    }
    int ptr = 0;
    if (seated > 0.5) {
        ivec3 rgb = ivec3(round(Color.rgb * 255.0));
        vec2 grid = vec2(0.0);
        if (rgb.r == 254 && rgb.g > 0 && rgb.b > 0) {
            ptr = 1;
            grid = vec2(rgb.gb);
            vec3 look = -vec3(ModelViewMat[0][2], ModelViewMat[1][2], ModelViewMat[2][2]);
            if (dot(Position, look) < 0.0) gl_Position = ProjMat * ModelViewMat * vec4(-Position.x, Position.y, -Position.z, 1.0);
        } else if (rgb.r == 253 && rgb.g > 0 && rgb.b > 0) {
            ptr = 2;
            gl_Position = mui_flat(mui_client_pointer(vec2(rgb.gb) * 128.0));
        } else if (rgb.r == 252) {
            ptr = 2;
            gl_Position = mui_flat(mui_free_pointer(vec2(2048.0, 1152.0), float(rgb.g), float(rgb.b)));
        } else if (mapKind == 3) {
            vec2 viewGrid = vec2(float(mui_symbol(ivec2(2, 0))), float(mui_symbol(ivec2(3, 0))));
            vec2 tile = vec2(float(mui_symbol(ivec2(2, 1))), float(mui_symbol(ivec2(3, 1))));
            if (tile.x == 239.0 && tile.y == 239.0) {
                mapKind = 5;
                gl_Position = mui_flat(vec2(-1.0) + vec2(muiUv.x * 8.0, (1.0 - muiUv.y) * 2.0) / ScreenSize);
            } else {
                vec2 at = (tile + muiUv) / viewGrid;
                gl_Position = mui_flat(vec2(at.x * 2.0 - 1.0, 1.0 - at.y * 2.0));
            }
        }
        if (grid.x > 0.0 && grid.y > 0.0) {
            vec2 blocks = gl_Position.xy / vec2(ProjMat[0][0], ProjMat[1][1]);
            gl_Position.xy = blocks / (grid * 0.5) * gl_Position.w;
        }
    }
    if (mapKind >= 3 && seated < 0.5) gl_Position = vec4(0.0, 0.0, 2.0, 1.0);
#ifdef IS_SEE_THROUGH
    if (seated > 0.5 && ptr == 0) gl_Position = vec4(0.0, 0.0, 2.0, 1.0);
#endif
    if (ptr > 0) {
        float light = clamp(vertexColor.r / max(Color.r, 0.004), 0.0, 1.0);
        vertexColor = vec4(vec3(light), 16.0 * float(ptr) + (rev ? 8.0 : 0.0) + Color.a);
    } else if (mapKind >= 3) {
        bool fill = mui_fill_right(2) > 0.5;
        ivec4 tint = mui_tint_symbols();
        int red = mapKind | (fill ? 8 : 0) | (rev ? 1024 : 0);
        vertexColor = vec4(float(red), float(muiBase.x / 128 + 64 * (muiBase.y / 128)),
                           float(tint.x * 256 + tint.y), 65536.0 + float(tint.z * 256 + tint.w));
    }
}

void main() {
    mui_vanilla_vertex();
#ifdef IS_GUI
    mui_gui_vertex();
#else
    mui_world_vertex();
#endif
}
