#version 330
#extension GL_ARB_separate_shader_objects : require

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:globals.glsl>
#include <minecraft:oit.glsl>

uniform sampler2D Sampler0;

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
#endif

layout(location = 2) in vec4 vertexColor;
layout(location = 3) in vec2 texCoord0;

#ifndef OIT_ALPHA_ONLY
layout(location = 0) out vec4 fragColor;
#endif

vec4 calculateFinalColor(vec4 color) {
    #ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
    #endif
    #if !defined(IS_SEE_THROUGH) && !defined(IS_GUI)
    #ifdef OIT_ACCUMULATE
    vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
    #else
    vec4 fogColor = FogColor;
    #endif
    color = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
    #endif
    return color;
}

void mui_vanilla_fragment() {
    #ifdef IS_GRAYSCALE
    vec4 texColor = texture(Sampler0, texCoord0).rrrr;
    #else
    vec4 texColor = texture(Sampler0, texCoord0);
    #endif
    vec4 color = texColor * vertexColor * ColorModulator;
    if (color.a < 0.1) discard;
    #ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
    #else
    fragColor = calculateFinalColor(color);
    #endif
}

uint mui_mul(uint a, uint b) {
    uint al = a & 65535u, ah = a >> 16u, bl = b & 65535u, bh = b >> 16u;
    return al * bl + ((al * bh + ah * bl) << 16u);
}
uint mui_displacements(uint i) {
    uvec4 t0_0 = (i & 8u) != 0u ? uvec4(391774590u, 1662151960u, 339798529u, 53280883u) : uvec4(906494208u, 342563082u, 67249448u, 161304064u);
    uvec4 t0_1 = (i & 8u) != 0u ? uvec4(2843839628u, 2316404752u, 679716608u, 3477053313u) : uvec4(25034762u, 2349278011u, 118704130u, 203165200u);
    uvec4 t1_0 = (i & 4u) != 0u ? t0_1 : t0_0;
    uvec2 h = (i & 2u) != 0u ? t1_0.zw : t1_0.xy;
    return (i & 1u) != 0u ? h.y : h.x;
}
int mui_symbol_of(vec3 rgb) {
    uvec3 c = uvec3(round(rgb * 255.0));
    uint k = (c.r << 16u) | (c.g << 8u) | c.b;
    uint b = mui_mul(k, 1372926309u) >> 26u;
    uint s = ((mui_mul(k, 3137834733u) >> 24u) * 240u >> 8u) + ((mui_displacements(b >> 2u) >> ((b & 3u) << 3u)) & 255u);
    return int(s >= 240u ? s - 240u : s);
}
ivec2 muiBase = ivec2(0);
ivec3 mui_fetch(ivec2 p) { return ivec3(round(texelFetch(Sampler0, muiBase + p, 0).rgb * 255.0)); }
int mui_symbol(ivec2 p) { return mui_symbol_of(texelFetch(Sampler0, muiBase + p, 0).rgb); }
ivec4 mui_symbols(ivec2 p, vec3 first) {
    return ivec4(mui_symbol_of(first), mui_symbol(p + ivec2(1, 0)), mui_symbol(p + ivec2(0, 1)), mui_symbol(p + ivec2(1, 1)));
}
int mui_texture() {
    ivec2 size = textureSize(Sampler0, 0);
    if (size == ivec2(128, 128)) return 1;
    return size.x == size.y && size.x >= 256 && (size.x & 127) == 0 ? 2 : 0;
}
bool mui_in_texture(ivec2 base, ivec2 size) { return all(greaterThanEqual(base, ivec2(0))) && all(lessThan(base, size)); }
int mui_screen_map() {
    ivec3 m0 = mui_fetch(ivec2(0, 0)), m1 = mui_fetch(ivec2(1, 0));
    if (m0 != ivec3(89, 117, 105) || m1 != ivec3(109, 144, 129)) return 0;
    ivec3 a = mui_fetch(ivec2(0, 1)), b = mui_fetch(ivec2(1, 1));
    if (a == ivec3(67, 88, 79) && b == ivec3(67, 88, 79)) return 3;
    if (a == ivec3(127, 167, 150) && b == ivec3(67, 88, 79)) return 1;
    return 0;
}
vec4 mui_block(ivec2 b) {
    ivec2 p = b * 2;
    vec4 c00 = texelFetch(Sampler0, muiBase + p, 0);
    if (c00.a < 0.5) return vec4(0.0);
    ivec4 s = mui_symbols(p, c00.rgb);
    ivec4 digit = s & 7;
    return vec4(dot(vec4(s >> 3), vec4(0.25)) / 29.0, float(digit.x * 8 + digit.y - 32) / 63.0,
                float(digit.z * 8 + digit.w - 32) / 63.0, 1.0);
}
float mui_fill_right(int info) {
    vec4 a = mui_block(ivec2(info + 1, 0)), b = mui_block(ivec2(info + 1, 1));
    if (a.w != b.w) return 1.0;
    vec4 d = abs(a - b);
    return d.x + 0.5 * (d.y + d.z) > 0.06 ? 1.0 : 0.0;
}

vec4 mui_sample(vec2 t, vec2 fw, int info, bool fillRight) {
    vec2 halfFw = clamp(fw, vec2(0.02), vec2(2.0)) * 0.5;
    vec2 lo = clamp(t - halfFw, vec2(0.0), vec2(128.0));
    vec2 hi = clamp(t + halfFw, vec2(0.0), vec2(128.0));
    ivec2 b0 = clamp(ivec2(floor(lo * 0.5)), ivec2(0), ivec2(63));
    ivec2 b1 = clamp(ivec2(floor((hi - 0.0001) * 0.5)), ivec2(0), ivec2(63));
    vec3 acc = vec3(0.0);
    float total = 0.0;
    float covered = 0.0;
    for (int i = 0; i < 4; i++) {
        ivec2 b = b0 + ivec2(i & 1, i >> 1);
        if (b.x > b1.x || b.y > b1.y) continue;
        ivec2 base = b * 2;
        vec2 p0 = vec2(base);
        vec2 ov0 = max(min(hi, p0 + 1.0) - max(lo, p0), 0.0);
        vec2 ov1 = max(min(hi, p0 + 2.0) - max(lo, p0 + 1.0), 0.0);
        vec4 w = vec4(ov0.x * ov0.y, ov1.x * ov0.y, ov0.x * ov1.y, ov1.x * ov1.y);
        float ws = w.x + w.y + w.z + w.w;
        total += ws;
        ivec2 src = b.y > 0 || b.x > info ? base : fillRight ? ivec2(2 * info + 2, 0) : ivec2(base.x, 2);
        vec4 c00 = texelFetch(Sampler0, muiBase + src, 0);
        if (c00.a < 0.5) continue;
        ivec4 s = mui_symbols(src, c00.rgb);
        vec4 luma = vec4(s >> 3) / 29.0;
        ivec4 digit = s & 7;
        vec2 chroma = vec2(float(digit.x * 8 + digit.y - 32), float(digit.z * 8 + digit.w - 32)) / 63.0;
        acc += vec3(dot(w, luma), chroma * ws);
        covered += ws;
    }
    if (covered <= 0.0) return vec4(0.0);
    vec3 ycc = acc / covered;
    return vec4(clamp(vec3(ycc.x + 1.402 * ycc.z, ycc.x - 0.344136 * ycc.y - 0.714136 * ycc.z, ycc.x + 1.772 * ycc.y), 0.0, 1.0),
                covered / max(total, 1e-6));
}

void mui_emit(vec4 c, float depth) {
#ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(depth, c.a);
#else
#ifdef OIT_ACCUMULATE
    c = sampleColorForAccumulation(c);
#endif
    fragColor = c;
#endif
}

vec3 mui_signature(int i, vec4 tint, bool reversed) {
    ivec4 t = ivec4(round(clamp(tint, 0.0, 1.0) * 255.0));
    int flags = mui_symbol(ivec2(6, 0)) | (reversed ? 4 : 0);
    ivec3 c = i == 0 ? ivec3(90,195,150) : i == 1 ? t.rgb : i == 2 ? ivec3(t.a, flags, 0) : ivec3(0, 0, 105);
    return vec3(c) / 255.0;
}

float vfx_hash(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

float vfx_noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    vec2 u = f * f * (3.0 - 2.0 * f);
    return mix(
            mix(vfx_hash(i), vfx_hash(i + vec2(1.0, 0.0)), u.x),
            mix(vfx_hash(i + vec2(0.0, 1.0)), vfx_hash(i + vec2(1.0, 1.0)), u.x),
            u.y
    );
}

float vfx_fbm2(vec2 p) {
    return 0.62 * vfx_noise(p) + 0.38 * vfx_noise(p * 2.13 + vec2(11.7, 5.3));
}

float vfx_bayer(ivec2 c) {
    int x = c.x & 3;
    int y = c.y & 3;
    int b = (((x ^ y) & 1) << 3) | ((y & 1) << 2) | ((x ^ y) & 2) | ((y & 2) >> 1);
    return (float(b) + 0.5) / 16.0;
}

vec4 vfx_tint(float intensity, float bayer, vec3 darkEdge, vec3 midCol, vec3 brightCore) {
    if (intensity + (bayer - 0.5) * 0.18 < 0.14) return vec4(0.0);
    vec3 col = mix(darkEdge, midCol, clamp(intensity * 1.35, 0.0, 1.0));
    if (intensity > 0.55) col = mix(col, brightCore, clamp((intensity - 0.55) * 2.1, 0.0, 1.0));
    return vec4(col, clamp(intensity * 1.15, 0.0, 0.96));
}

vec4 mui_vfx_color(int fxId, float p, vec2 rawUv) {
    ivec2 cell = ivec2(floor(clamp(rawUv, 0.0, 0.9999) * 64.0));
    vec2 uv = (vec2(cell) + 0.5) / 64.0;
    vec2 d = (uv - 0.5) * 2.0;
    float dist = length(d);
    float ang = atan(d.y, d.x);
    float bayer = vfx_bayer(cell);
    float fadeOut = 1.0 - smoothstep(0.68, 1.0, p);
    float fadeIn = smoothstep(0.0, 0.12, p);
    float t = GameTime * 36.0;

    int shape = 2;
    int pal = 1;
    if (fxId >= 32) {
        shape = fxId / 16;
        pal = fxId - shape * 16;
    } else {
        if (fxId == 1)  { shape = 2;  pal = 1; } // TERMINUS Ability -> SLASH + CRIMSON
        if (fxId == 2)  { shape = 3;  pal = 1; } // TERMINUS Ult -> X_CLEAVE + CRIMSON
        if (fxId == 3)  { shape = 6;  pal = 2; } // WORLDWEIGHT Ability -> SHOCKWAVE + INDIGO
        if (fxId == 4)  { shape = 7;  pal = 2; } // WORLDWEIGHT Ult -> MAGIC_CIRCLE + INDIGO
        if (fxId == 5)  { shape = 8;  pal = 3; } // ACCRETION Ability -> VORTEX + AMETHYST
        if (fxId == 6)  { shape = 9;  pal = 3; } // ACCRETION Ult -> NOVA + AMETHYST
        if (fxId == 7)  { shape = 2;  pal = 1; } // CAUSALITY Cut -> SLASH + CRIMSON
        if (fxId == 8)  { shape = 7;  pal = 1; } // CAUSALITY Charge -> MAGIC_CIRCLE + CRIMSON
        if (fxId == 9)  { shape = 4;  pal = 3; } // OBSERVER Ability -> FAN_SWEEP + AMETHYST
        if (fxId == 10) { shape = 7;  pal = 3; } // OBSERVER Ult -> MAGIC_CIRCLE + AMETHYST
        if (fxId == 11) { shape = 5;  pal = 4; } // IMPETUS Ability -> THRUST_RING + CERULEAN
        if (fxId == 12) { shape = 11; pal = 4; } // IMPETUS Ult -> PILLAR_SIGIL + CERULEAN
        if (fxId == 13) { shape = 8;  pal = 2; } // AKASHIC Ability -> VORTEX + INDIGO
        if (fxId == 14) { shape = 7;  pal = 2; } // AKASHIC Ult -> MAGIC_CIRCLE + INDIGO
        if (fxId == 15) { shape = 10; pal = 5; } // ASSIMILATOR Claw -> CLAW + JADE
        if (fxId == 16) { shape = 8;  pal = 5; } // ASSIMILATOR Domain -> VORTEX + JADE
        if (fxId == 17) { shape = 6;  pal = 1; } // CAUSALITY Rupture -> SHOCKWAVE + CRIMSON
    }

    vec3 darkEdge = vec3(0.42, 0.04, 0.10), midCol = vec3(0.86, 0.12, 0.24), brightCore = vec3(1.0, 0.52, 0.58);
    if (pal == 2) { darkEdge = vec3(0.18, 0.08, 0.45); midCol = vec3(0.44, 0.24, 0.88); brightCore = vec3(0.74, 0.62, 1.0); }
    else if (pal == 3) { darkEdge = vec3(0.26, 0.06, 0.48); midCol = vec3(0.62, 0.20, 0.92); brightCore = vec3(0.86, 0.58, 1.0); }
    else if (pal == 4) { darkEdge = vec3(0.05, 0.26, 0.48); midCol = vec3(0.14, 0.62, 0.90); brightCore = vec3(0.58, 0.90, 1.0); }
    else if (pal == 5) { darkEdge = vec3(0.04, 0.30, 0.18); midCol = vec3(0.14, 0.72, 0.42); brightCore = vec3(0.54, 0.96, 0.72); }
    else if (pal == 6) { darkEdge = vec3(0.46, 0.26, 0.04); midCol = vec3(0.88, 0.60, 0.14); brightCore = vec3(1.0, 0.88, 0.48); }
    else if (pal == 7) { darkEdge = vec3(0.24, 0.26, 0.32); midCol = vec3(0.62, 0.66, 0.74); brightCore = vec3(0.92, 0.94, 0.98); }

    float intensity = 0.0;
    if (shape == 2) {
        // 1. SLASH: tapered crescent slash
        float snap = 1.0 - pow(1.0 - clamp(p * 2.5, 0.0, 1.0), 3.0);
        float sweep = smoothstep(-1.02, -0.82, d.x) * (1.0 - smoothstep(mix(-0.82, 1.02, snap) - 0.14, mix(-0.82, 1.02, snap) + 0.06, d.x));
        float n = vfx_fbm2(d * 4.2 + vec2(-t * 0.18, p * 3.2));
        float taper = pow(max(0.0, 1.0 - d.x * d.x), 1.25);
        float curveY = d.y - 0.14 * (1.0 - d.x * d.x) + (n - 0.5) * 0.06 * p;
        float w = (0.020 + 0.095 * taper) * (1.0 - 0.28 * p);
        intensity = exp(-pow(curveY / max(0.012, w), 2.0)) * sweep * (0.78 + 0.38 * n) * fadeIn * fadeOut;
    } else if (shape == 3) {
        // 2. X_CLEAVE: crossed dimensional cleave + ring
        float n = vfx_fbm2(d * 3.2 - vec2(t * 0.12, p * 2.8));
        float xCut1 = exp(-abs(d.y - d.x * 0.45 + (n - 0.5) * 0.08) / (0.036 + 0.055 * sin(p * 3.14159))) * smoothstep(0.95, 0.2, abs(d.x));
        float xCut2 = exp(-abs(d.y + d.x * 0.45 - (n - 0.5) * 0.08) / (0.036 + 0.055 * sin(p * 3.14159))) * smoothstep(0.95, 0.2, abs(d.x));
        float ringR = 0.32 + 0.56 * pow(p, 0.7);
        float ring = exp(-pow((dist - ringR) / 0.032, 2.0)) * 0.78;
        intensity = max(max(xCut1, xCut2), ring) * fadeIn * fadeOut;
    } else if (shape == 4) {
        // 3. FAN_SWEEP: 120-deg sweeping fan arc
        float arcR = 0.56 + 0.26 * p;
        float sweepHead = mix(-1.1, 1.1, smoothstep(0.0, 0.60, p));
        float fanMask = smoothstep(-1.25, -0.85, ang) * (1.0 - smoothstep(sweepHead - 0.35, sweepHead + 0.12, ang));
        float n = vfx_fbm2(vec2(cos(ang), sin(ang)) * 3.8 + vec2(t * 0.18, p * 3.0));
        float ring = exp(-pow((dist - arcR + (n - 0.5) * 0.08) / 0.080, 2.0));
        intensity = ring * (0.45 + 0.75 * fanMask) * fadeIn * fadeOut * (0.75 + 0.4 * n);
    } else if (shape == 5) {
        // 4. THRUST_RING: expanding piercing shock ring
        float n = vfx_fbm2(vec2(cos(ang), sin(ang)) * 4.2 + vec2(t * 0.3, p * 3.5));
        float ringR = 0.22 + 0.68 * pow(p, 0.65);
        intensity = exp(-pow((dist - ringR + (n - 0.5) * 0.06) / 0.055, 2.0)) * fadeOut;
    } else if (shape == 6) {
        // 5. SHOCKWAVE: expanding AOE ring + 6 ground fracture lines
        float n = vfx_fbm2(vec2(cos(ang), sin(ang)) * 4.0 + vec2(p * 2.5, t * 0.08));
        float ringR = 0.14 + 0.82 * pow(p, 0.55);
        float mainRing = exp(-pow((dist - ringR + (n - 0.5) * 0.05) / 0.058, 2.0));
        float spokes = pow(0.5 + 0.5 * cos(ang * 6.0 + n * 2.5), 8.0) * smoothstep(ringR, 0.1, dist) * 0.72;
        intensity = max(mainRing, spokes) * fadeOut;
    } else if (shape == 7) {
        // 6. MAGIC_CIRCLE: rotating geometric rune circle
        float c1 = cos(t * 0.22), s1 = sin(t * 0.22);
        vec2 r1 = vec2(d.x * c1 - d.y * s1, d.x * s1 + d.y * c1);
        float sq1 = exp(-abs(max(abs(r1.x), abs(r1.y)) - 0.58) / 0.024);
        float c2 = cos(-t * 0.22 + 0.7854), s2 = sin(-t * 0.22 + 0.7854);
        vec2 r2 = vec2(d.x * c2 - d.y * s2, d.x * s2 + d.y * c2);
        float sq2 = exp(-abs(max(abs(r2.x), abs(r2.y)) - 0.58) / 0.024);
        float outerRing = exp(-pow((dist - 0.86) / 0.026, 2.0));
        float innerRing = exp(-pow((dist - 0.42) / 0.022, 2.0)) * 0.75;
        intensity = max(max(sq1, sq2), max(outerRing, innerRing)) * fadeIn * (1.0 - smoothstep(0.90, 1.0, p));
    } else if (shape == 8) {
        // 7. VORTEX: inward-pulling spiral vortex
        float n = vfx_fbm2(d * 3.5 + vec2(t * 0.18, -t * 0.18));
        float spiral = pow(0.5 + 0.5 * cos(ang * 3.0 + dist * 9.0 + t * 0.8), 2.6) * smoothstep(0.94, 0.1, dist);
        float pullRing = exp(-pow((dist - (0.88 - 0.72 * p)) / 0.048, 2.0));
        intensity = max(spiral * (0.65 + 0.4 * n), pullRing) * fadeIn * fadeOut;
    } else if (shape == 9) {
        // 8. NOVA: radial burst + expanding halo
        float rays = pow(0.5 + 0.5 * cos(ang * 6.0 + t * 0.35), 7.0) * smoothstep(0.95, 0.10, dist) * 0.78;
        float halo = exp(-pow((dist - (0.18 + 0.70 * p)) / 0.058, 2.0));
        float core = exp(-dist * (4.8 - 1.8 * p));
        intensity = max(max(core, halo), rays) * fadeIn * fadeOut;
    } else if (shape == 10) {
        // 9. CLAW: 3 parallel claw gashes
        float n = vfx_fbm2(d * 4.0 + vec2(t * 0.18, p * 2.5));
        float diag = d.y - d.x * 0.65 + (n - 0.5) * 0.05;
        float cA = exp(-abs(diag - 0.26) / 0.032) * smoothstep(0.88, 0.1, abs(d.x));
        float cB = exp(-abs(diag) / 0.038) * smoothstep(0.94, 0.1, abs(d.x));
        float cC = exp(-abs(diag + 0.26) / 0.032) * smoothstep(0.88, 0.1, abs(d.x));
        intensity = max(max(cA, cB), cC) * fadeIn * fadeOut;
    } else {
        // 10. PILLAR_SIGIL: 4-point star sigil + impact ring
        float rays = pow(0.5 + 0.5 * cos(ang * 4.0), 10.0) * smoothstep(0.95, 0.05, dist);
        float ring = exp(-pow((dist - (0.28 + 0.56 * p)) / 0.038, 2.0));
        float core = exp(-dist * 4.6);
        intensity = max(max(rays, ring), core) * fadeIn * fadeOut;
    }

    return vfx_tint(intensity, bayer, darkEdge, midCol, brightCore);
}

#ifndef IS_GUI
bool mui_fragment(vec2 footprint) {
    vec4 code = vertexColor;
    if (code.w >= 1024.0 - 0.5 && code.w < 1024.0 + 512.0) {
        vec4 vfx = mui_vfx_color(int(round(code.r)), clamp(code.g, 0.0, 1.0), texCoord0);
        if (vfx.a < 0.05) discard;
        gl_FragDepth = gl_FragCoord.z;
        mui_emit(vfx, gl_FragCoord.z);
        return true;
    }
    if (code.w >= 16.0 - 0.5 && code.w < 65536.0 - 0.5) {
        int kind = int(floor(code.w / 16.0));
        float rest = code.w - 16.0 * float(kind);
        bool rev = rest > 4.0;
        float alpha = clamp(rest - (rev ? 8.0 : 0.0), 0.0, 1.0);
        vec4 tex = texture(Sampler0, texCoord0);
        tex.a = min(1.0, tex.a * 10.6250);
        vec4 color = tex * vec4(code.rgb, alpha) * ColorModulator;
        if (color.a < 0.1) discard;
        float depth = rev ? 1.0 : 0.0;
        gl_FragDepth = depth;
        mui_emit(color, depth);
        return true;
    }
    if (code.w < 65536.0 - 0.5) return false;
    int red = int(round(code.r));
    int mapKind = red & 7;
    int green = int(round(code.g));
    int blue = int(round(code.b));
    int alpha = int(round(code.w - 65536.0));
    bool fill = (red & 8) != 0;
    bool rev = (red & 1024) != 0;
    muiBase = ivec2(green % 64, green / 64) * 128;
    vec2 scale = vec2(textureSize(Sampler0, 0)) / 128.0;
    vec2 tex = texCoord0 * 128.0 * scale - vec2(muiBase);
    vec4 viewTint = vec4(float(blue >> 8), float(blue & 255), float(alpha >> 8), float(alpha & 255)) / 239.0;
    if (mapKind == 5) {
        if (gl_FragCoord.y >= 1.0 || gl_FragCoord.x >= 4.0) discard;
        vec4 sigCol = vec4(mui_signature(int(gl_FragCoord.x), viewTint, rev), 1.0);
        float sigDepth = rev ? 1.0 : 0.0;
        gl_FragDepth = sigDepth;
        mui_emit(sigCol, sigDepth);
        return true;
    }
    footprint *= scale;
    vec4 pic = mui_sample(tex, footprint, 2, fill);
    vec4 tint = pic.a < 1.0 ? viewTint : vec4(0.0);
    float a = 1.0 - (1.0 - pic.a) * (1.0 - tint.a);
    if (a < 0.002) discard;
    vec4 col = vec4((pic.rgb * pic.a + tint.rgb * (tint.a * (1.0 - pic.a))) / max(a, 0.002), a);
    float depth = rev ? 0.99999 : 0.00001;
    gl_FragDepth = depth;
    mui_emit(col, depth);
    return true;
}
#endif

void main() {
    vec2 footprint = fwidth(texCoord0 * 128.0);
#ifndef IS_GUI
    gl_FragDepth = gl_FragCoord.z;
#ifndef IS_GRAYSCALE
    if (mui_fragment(footprint)) return;
#endif
#endif
    mui_vanilla_fragment();
}
