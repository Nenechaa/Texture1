#version 330
#extension GL_ARB_separate_shader_objects : require

layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    mat4 TextureMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
};
layout(std140) uniform Projection {
    mat4 ProjMat;
};
layout(std140) uniform Globals {
    ivec3 CameraBlockPos;
    float GlintAlpha;
    vec3 CameraOffset;
    float GameTime;
    vec2 ScreenSize;
    int MenuBlurRadius;
    int UseRgss;
};

layout(location = 0) in vec3 Position;
layout(location = 1) in vec2 UV0;
layout(location = 2) in vec4 Color;

layout(location = 0) out vec2 texCoord0;
layout(location = 1) out vec4 vertexColor;
layout(location = 2) out vec2 muiPos;
layout(location = 3) flat out vec2 muiSize;
layout(location = 4) flat out float muiSeated;

bool mui_near(float v, float t) { return abs(v - t) < 0.0001; }
bool mui_grid(float v) { return mui_near(v, 0.0) || mui_near(v, 0.5) || mui_near(v, 1.0); }
float mui_flag(float v) { return (abs(fract(v * 16.0) - 0.375000) < 0.002 || abs(fract(-v * 16.0) - 0.375000) < 0.002) ? 1.0 : 0.0; }
int mui_flag_axis() {
    vec3 f = -CameraOffset;
    if (mui_flag(f.x) > 0.0 && mui_flag(f.y) > 0.0 && mui_flag(f.z) > 0.0) return 1;
    if (mui_flag(f.x) > 0.0) return 0;
    if (mui_flag(f.z) > 0.0) return 2;
    return -1;
}
float mui_seated_flag() { return mui_flag_axis() >= 0 ? 1.0 : 0.0; }
float mui_seated_now() { return ProjMat[3][3] != 1.0 ? 0.0 : mui_seated_flag(); }
vec2 mui_gui_size() { return vec2(2.0 / abs(ProjMat[0][0]), 2.0 / abs(ProjMat[1][1])); }
float mui_reversed() { return ProjMat[2][2] > -0.5 ? 1.0 : 0.0; }

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
    texCoord0 = UV0;
    vertexColor = Color;
    muiPos = (ModelViewMat * vec4(Position, 1.0)).xy;
    muiSize = mui_gui_size();
    muiSeated = (CameraBlockPos != ivec3(0, 0, 0)) ? mui_seated_now() : 0.0;
    if (ProjMat[3][3] != 1.0 && mui_flag_axis() >= 0 && length((ModelViewMat * vec4(Position, 1.0)).xyz) < 2.0) {
        gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
    }
}
