#version 330
#extension GL_ARB_separate_shader_objects : require
#include <minecraft:globals.glsl>
layout(std140) uniform SamplerInfo { vec2 OutSize; };
layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;
ivec3 ov_texel(sampler2D s, int x) { return ivec3(round(texelFetch(s, ivec2(x, 0), 0).rgb * 255.0)); }
int ov_signature(sampler2D s, out vec4 tint) {
    tint = vec4(0.0);
    ivec3 c0 = ov_texel(s, 0), c3 = ov_texel(s, 3);
    if (c0 != ivec3(90, 195, 150) || c3 != ivec3(0, 0, 105)) return 0;
    ivec3 c1 = ov_texel(s, 1), c2 = ov_texel(s, 2);
    tint = vec4(vec3(c1), float(c2.r)) / 255.0;
    return c2.g | 8;
}
uniform sampler2D InSampler;
void main() { vec4 tint; if (ov_signature(InSampler, tint) == 0) discard; fragColor = vec4(0.0); }