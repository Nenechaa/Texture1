#version 330
#extension GL_ARB_separate_shader_objects : require
#include <minecraft:globals.glsl>
layout(std140) uniform SamplerInfo { vec2 OutSize; };
layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;
ivec3 ov_texel(sampler2D s, int x) { return ivec3(round(texelFetch(s, ivec2(x, 0), 0).rgb * 255.0)); }
int ov_signature(sampler2D s, out vec4 tint) {
    tint = vec4(0.0);
    ivec3 c0 = ov_texel(s, 0), c3 = ov_texel(s, 3);
    if (c0 != ivec3(90, 195, 150) || c3 != ivec3(0, 0, 105)) return 0;
    ivec3 c1 = ov_texel(s, 1), c2 = ov_texel(s, 2);
    tint = vec4(vec3(c1), float(c2.r)) / 255.0;
    return c2.g | 8;
}
uniform sampler2D InSampler;
uniform sampler2D KeptSampler;
vec3 ov_safe(vec2 uv) {
    ivec2 sz = textureSize(InSampler, 0);
    ivec2 p = clamp(ivec2(floor(uv * vec2(sz))), ivec2(0), sz - 1);
    if (p.y == 0 && p.x < 4) p.y = 1;
    return texelFetch(InSampler, p, 0).rgb;
}
float ov_hash(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}
float ov_noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    vec2 u = f * f * (3.0 - 2.0 * f);
    return mix(
            mix(ov_hash(i), ov_hash(i + vec2(1.0, 0.0)), u.x),
            mix(ov_hash(i + vec2(0.0, 1.0)), ov_hash(i + vec2(1.0, 1.0)), u.x),
            u.y
    );
}
float ov_fbm(vec2 p) {
    float sum = 0.0;
    float amp = 0.5;
    mat2 m = mat2(0.80, -0.60, 0.60, 0.80);
    for (int i = 0; i < 4; i++) {
        sum += amp * ov_noise(p);
        p = m * p * 2.02 + vec2(17.3, 9.1);
        amp *= 0.5;
    }
    return sum;
}
float ov_bayer(ivec2 c) {
    int x = c.x & 3;
    int y = c.y & 3;
    int b = (((x ^ y) & 1) << 3) | ((y & 1) << 2) | ((x ^ y) & 2) | ((y & 2) >> 1);
    return (float(b) + 0.5) / 16.0;
}
vec3 ov_ditherPalette(float v, float bayer) {
    float idx = clamp(floor(clamp(v, 0.0, 0.999) * 5.0 + bayer), 0.0, 5.0);
    if (idx < 0.5) return vec3(0.020, 0.008, 0.039);
    if (idx < 1.5) return vec3(0.102, 0.031, 0.188);
    if (idx < 2.5) return vec3(0.231, 0.051, 0.439);
    if (idx < 3.5) return vec3(0.494, 0.133, 0.808);
    if (idx < 4.5) return vec3(0.753, 0.518, 0.988);
    return vec3(0.961, 0.816, 0.996);
}
void main() {
    ivec2 at = ivec2(gl_FragCoord.xy); vec4 tint;
    int flags = ov_signature(InSampler, tint);
    if (flags == 0) discard;
    bool signature = at.y == 0 && at.x < 4;
    if ((flags & 16) != 0) {
        vec2 sz = max(OutSize, vec2(1.0));
        vec2 uv = (vec2(at) + 0.5) / sz;
        float p = clamp(tint.a, 0.0, 1.0);
        float aspect = sz.x / sz.y;
        vec2 grid = vec2(floor(270.0 * aspect + 0.5), 270.0);
        ivec2 cell = ivec2(floor(uv * grid));
        vec2 puv = (vec2(cell) + 0.5) / grid;
        float bayer = ov_bayer(cell);

        vec2 shake = vec2(sin(GameTime * 460.0), cos(GameTime * 410.0 + 1.3))
                * (smoothstep(0.0, 0.28, p) * (1.0 - smoothstep(0.66, 0.80, p)) * 0.0065);
        vec2 d = (puv - vec2(0.5)) + shake;
        vec2 da = vec2(d.x * aspect, d.y);
        float dist = length(da);
        float ang = atan(da.y, da.x);
        float logR = log(dist + 0.04);
        float tFlow = GameTime * 18.0 + p * 7.5;

        vec2 nUv1 = vec2(cos(ang + logR * 3.0 - tFlow * 0.25), sin(ang + logR * 3.0 - tFlow * 0.25)) * (2.4 + logR * 0.55) + vec2(tFlow * 0.18, -tFlow * 0.12);
        vec2 nUv2 = vec2(cos(ang - logR * 2.2 + tFlow * 0.35), sin(ang - logR * 2.2 + tFlow * 0.35)) * (4.2 + logR * 0.85) + vec2(-tFlow * 0.22, tFlow * 0.15);
        float turb = ov_fbm(nUv1 * 1.6);
        float edgeN = ov_fbm(nUv2 * 1.4 + vec2(turb * 1.5));
        vec3 voidBlack = vec3(0.020, 0.008, 0.039);

        vec3 col;
        if (p < 0.78) {
            float charge = smoothstep(0.0, 0.28, p);
            float pull = smoothstep(0.16, 0.76, p);
            float rot = (pull * pull * 5.0 + turb * 0.45 * pull) / (dist + 0.24);
            float ca = pull * (0.004 + 0.022 * dist);

            vec3 acc = vec3(0.0);
            for (int k = 0; k < 6; k++) {
                float tk = float(k) / 5.0;
                float sc = mix(1.0 + pull * 0.10, 0.56, tk * pull);
                float rk = rot * (0.55 + 0.45 * tk);
                float cr = cos(rk);
                float sr = sin(rk);
                vec2 rda = vec2(da.x * cr - da.y * sr, da.x * sr + da.y * cr) * sc;
                vec2 u0 = vec2(0.5) + vec2(rda.x / aspect, rda.y);
                float r = ov_safe(u0 + vec2(da.x / aspect, da.y) * ca).r;
                float g = ov_safe(u0).g;
                float b = ov_safe(u0 - vec2(da.x / aspect, da.y) * ca).b;
                acc += vec3(r, g, b);
            }
            vec3 bgCol = acc / 6.0;
            float vig = smoothstep(0.18, 1.05, dist) * (0.70 * charge + 0.28 * pull);
            bgCol = mix(bgCol * max(0.06, 1.0 - vig), voidBlack, clamp(pull * 0.45, 0.0, 1.0));

            float warpArms = smoothstep(0.32, 0.86, turb * 0.7 + edgeN * 0.55);
            float spiralRib = 0.5 + 0.5 * cos(ang * 5.0 - logR * 7.5 + turb * 4.2 + tFlow * 2.2);
            float nebulaVal = clamp(warpArms * (0.55 + 0.55 * spiralRib) * smoothstep(0.03, 0.22, dist) * (0.35 * charge + 0.95 * pull), 0.0, 1.0);

            float starCell = ov_hash(floor(vec2(ang * 24.0 + logR * 12.0 + tFlow * 0.8, logR * 28.0 - tFlow * 2.5)));
            float shard = step(0.968, starCell) * smoothstep(0.08, 0.30, dist) * (0.4 * charge + 0.8 * pull);

            float coreR = 0.03 + 1.26 * pow(pull, 2.2) + (edgeN - 0.5) * 0.16;
            float rimBand = exp(-pow((dist - coreR) / (0.042 + 0.055 * pull), 2.0)) * (0.65 + 0.65 * edgeN);
            float rimVal = rimBand * (0.70 * charge + 1.15 * pull);
            float innerSwallow = smoothstep(coreR + 0.025, max(0.0, coreR - 0.035), dist);
            float voidSwallow = smoothstep(0.68, 0.775, p);

            float vfxVal = clamp(max(nebulaVal * 0.82, max(rimVal, shard * 0.95)), 0.0, 1.0);
            vec3 vfxCol = ov_ditherPalette(vfxVal, bayer);
            float vfxMix = clamp((vfxVal > 0.08 ? 0.35 + 0.65 * vfxVal : 0.0), 0.0, 1.0);

            col = mix(bgCol, vfxCol, vfxMix);
            if (vfxVal + (bayer - 0.5) * 0.22 > 0.35) {
                col = max(col, vfxCol);
            }
            col = mix(col, voidBlack, innerSwallow);
            if (rimVal + (bayer - 0.5) * 0.24 > 0.32) {
                col = ov_ditherPalette(clamp(rimVal, 0.0, 1.0), bayer);
            }
            col = mix(col, voidBlack, voidSwallow);
        } else {
            float openP = smoothstep(0.78, 0.99, p);
            float irisR = openP * 1.48 + (edgeN - 0.5) * 0.18;
            vec3 hubCol = ov_safe(uv);
            float inside = step(dist, irisR);
            float edgeGlow = exp(-pow((dist - irisR) / 0.065, 2.0)) * (0.70 + 0.60 * turb) * (1.0 - smoothstep(0.76, 1.0, openP));
            col = inside > 0.5 ? hubCol : voidBlack;
            if (edgeGlow + (bayer - 0.5) * 0.24 > 0.28) {
                col = ov_ditherPalette(clamp(edgeGlow * 1.1, 0.0, 1.0), bayer);
            }
        }

        fragColor = vec4(clamp(col, 0.0, 1.0), 1.0);
        return;
    }
    vec4 here = texelFetch(InSampler, at, 0);
    if (here.a > 0.5 && !signature) { fragColor = vec4(here.rgb, 1.0); return; }
    vec3 live = texelFetch(InSampler, signature ? ivec2(at.x, 1) : at, 0).rgb;
    if ((flags & 2) == 0) { fragColor = vec4(live, 1.0); return; }
    vec4 kept = texelFetch(KeptSampler, at, 0);
    fragColor = vec4(mix(kept.a > 0.5 ? kept.rgb : live, tint.rgb, tint.a), 1.0);
}