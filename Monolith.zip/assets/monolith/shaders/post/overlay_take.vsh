#version 330
#extension GL_ARB_separate_shader_objects : require
layout(location = 0) out vec2 texCoord;
ivec3 ov_texel(sampler2D s, int x) { return ivec3(round(texelFetch(s, ivec2(x, 0), 0).rgb * 255.0)); }
int ov_signature(sampler2D s, out vec4 tint) {
    tint = vec4(0.0);
    ivec3 c0 = ov_texel(s, 0), c3 = ov_texel(s, 3);
    if (c0 != ivec3(90, 195, 150) || c3 != ivec3(0, 0, 105)) return 0;
    ivec3 c1 = ov_texel(s, 1), c2 = ov_texel(s, 2);
    tint = vec4(vec3(c1), float(c2.r)) / 255.0;
    return c2.g | 8;
}
vec2 ov_uv() { vec2 uv = vec2((gl_VertexIndex << 1) & 2, gl_VertexIndex & 2); texCoord = uv; return uv; }
void ov_window(vec2 uv) { gl_Position = vec4(uv * 2.0 - 1.0, 0.0, 1.0); }
void ov_corner(vec2 uv, vec2 size) { gl_Position = vec4(uv * 2.0 / size - 1.0, 0.0, 1.0); }
void ov_none() { gl_Position = vec4(-2.0, -2.0, 0.0, 1.0); }
uniform sampler2D InSampler;
uniform sampler2D KeptSampler;
void main() {
    vec2 uv = ov_uv(); vec4 tint;
    int flags = ov_signature(InSampler, tint);
    if (flags == 0) ov_none();
    else if ((flags & 2) == 0 || texelFetch(KeptSampler, ivec2(0), 0).a < 0.5) ov_window(uv);
    else ov_corner(uv, vec2(textureSize(InSampler, 0)));
}